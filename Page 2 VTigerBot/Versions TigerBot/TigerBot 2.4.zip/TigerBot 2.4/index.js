const { Client, GatewayIntentBits, userMention, User, messageLink } = require('discord.js');
const client = new Client({ intents: [
    GatewayIntentBits.Guilds,
	GatewayIntentBits.GuildMessages,
	GatewayIntentBits.MessageContent,
	GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.GuildInvites,
],
});

client.on("ready", () => {
    console.log("Bot is online");
  });

const prefix = "*";

/// Commandes NORMALES
client.on("messageCreate", (message) => {

/// |- Messages Random
        const random1 = "ça va ?";
        const random2 = "coucou";
        const random3 = "comment tu vas ?";
        const random4 = "putin, qu'es-ce que je m'emmerde !";
        const random5 = "raaah je suis l'esclave de ce serveur";
        const random6 = "tu sais je suis un bot OpenSource, ce qui veut dire que tu peut obtenir mon code source rien qu'en demandant aux admins !";
        const random7 = "si tu veut tu peut rajouter de messages random en allant en proposer dans le salon #propositionmsg";
        const random8 = "XD";
        const random9 = ":zany_face:";
        const random10 = "XD";
        const random11 = ":stuck_out_tongue_closed_eyes:";
        const random12 = ":stuck_out_tongue_winking_eye:";
        const random13 = "je ne dit jamais de gros mots. héhé";
        const random14 = "tu hesite entre 2 choix ? essaye ça : https://wheelofnames.com/";
        const random15 = "vas y, tape des mots clés, et ecrit nimporte quoi apres avoir fait -entré- : https://docutyper.com/ tu vas voir, c'est cool"
        const random16 = "||lalalalalalalalalalalalalalalalalalalalalalalalala||"
        const random17 = "Tu connais -la Digitale- ? Non ? C'est un site qui regroupe des outils pédagogique, tu vas voire, il y a même un équivalent de Airdrop (digishare) ! \n || https://ladigitale.dev/ ||"
        const random18 = "Espèce de pu... personne très gentille"
        const random19 = "héhé https://slimber.com/img/images1/37/377028/hehehehe.jpg"
        const msgs = [random1, random2, random3, random4, random5, random6, random7, random8, random9, random10, random11, random12, random13, random14, random15, random16, random17, random18, random19];
        const randomMsg = msgs[Math.floor(Math.random() * msgs.length)];

    if (message.content == prefix + "aide"){
        message.channel.send(">>> - ** Commandes Normales ** : \n- `!aide` : commandes dispo \n- `!` : présentation du bot \n- `!imagerandom` : besoin d'une image random ? bah vas y \n- `!invite` : transmet le lien d'invitation du bot \n- `!addmessage` : ajoute un message à la liste de la commande !randommsg \n- `!info-utilisateur` : tout est dans le nom \n- `!serveur` : info du serveur\n- ** Commandes Fun ** \n- `!suuu` : suuuuu (ranaldo) \n- `!harold` : bah lui c'est ... harold quoi . \n- `!hey` : un message trés gentil \n- `!salut` : hé hé :smirk::smirk: \n- `!randommsg` : message parmi ceux ajoutés \n- `!vérité` : La vérité \n- `!Kleidung` : Deutsche Bestellung");
    }
    else if (message.content == prefix + "help"){
        message.channel.send(">>> - ** Normal Commands ** : \n- `!help` : commands available \n- `!` : bot overview \n- `!imagerandom` : need a random image? bah go y \n- `!invite`: pass the bot invitation link \n- `!addmessage` : adds a message to the list of the !randommsg command \n- `!info-utilisateur` : all is in the name \n- `!serveur` : server info \n- ** Fun commands ** \n- `!suuu` : suuuuuu (ranaldo) \n- `!harold` : just harold \n- `!hey` : a very nice message \n- `!salut` : hey hey :smirk::smirk: \n- `!randommsg` : message among those added \n- `!vérité` : The truth \n- `!Kleidung` : Deutsche Bestellung");
    }
    else if (message.content == prefix ){
        message.reply("Bonjour je suis TigerBot j'ai été créé par un petit programeur du nom de Vortix !! Je suis en constante évolution, car je m'améliore grâce à vos suggestions !  ");
    }
    else if (message.content === prefix + "imagerandom") {
        message.channel.send("tu veut une image au hasard ?? vas ici 👉 https://randompicturegenerator.com/");
    }
    else if (message.content === prefix + "invite") {
        message.channel.send(" Lien d'invitation👉 : https://dgxy.link//invitationsTigerBot");
    }
    else if (message.content == prefix + "randommsg"){
        message.reply(randomMsg);
    }
    else if (message.content === prefix + "addmessage"){
        const userId = message.author.id;
        message.reply(`<@${userId}>` + " écrit ton message en dessous");
    }
    else if (message.content == prefix + "serveur") {
        message.channel.send(`Nom du serveur : ${message.guild.name} \nNombre de Membres: ${message.guild.memberCount}`);
    }
    else if (message.content == prefix + "info-utilisateur") {
        message.channel.send(`Ton nom d'utilisateur: ${message.author.username} \nTon identifiant: ${message.author.id}`);
    }
});


/// Commandes CUSTOM
client.on("messageCreate", (message) => {
    if (message.content == prefix + "suuu"){
        message.channel.send("https://th.bing.com/th/id/R.616ff5ed375ce21b68e1809efab574db?rik=DQRl6W%2biLWw7gQ&pid=ImgRaw&r=0");
    }
    else if (message.content == prefix + "hey"){
        message.reply(" ## TG !!!!! tu peut la fermer STP ???!!!??? Si t'as pas compris quand des gens normaux te le disaient, là c'est un bot qui te le dit !!! donc FERME LÀ !!");
    }
    else if (message.content == prefix + "salut"){
        message.channel.send("Salutation Voyageur ! cette vidéo est bien évidement la suite de..... réagit :sunglasses: si t'as le ref' !")
    }
    else if (message.content == prefix + "harold"){
        message.channel.send("https://th.bing.com/th/id/OIP.ZYZauRtl8yHK0i0OaadyNwAAAA?pid=ImgDet&rs=1"),
        message.channel.send("https://th.bing.com/th?id=OIP.YjJSBQVO5Cy9RBxwNqfj7AHaJ5&w=216&h=289&c=8&rs=1&qlt=90&o=6&dpr=1.5&pid=3.1&rm=2");
        message.channel.send("tu préfère laquelle ?? XD")
    }
    else if (message.content == prefix + "vérité"){
        message.reply(" ``` Vous savez moi les pyramides je ne crois pas que ce sois les égyptiens qui les ai construites, faut vraiment être con pour croire ça ! Mais moi j'ai été informé par Sylvain Durrif, le christ cosmique, élu par la vierge en personne. (Running gag) ``` ")
    }
    else if (message.content == prefix + "Kleidung") {
        message.channel.send("Oh nein, meine Kleidung ist schmutzig. Es ist viel Staub drauf"); // Oh non, mes vêtements sont sales. Il y a beaucoup de poussière dessus
    }
});
// Easter Egg
client.on("messageCreate", (message) => {
    if (message.content == prefix + prefix){
        message.channel.send("bah t'es con ou quoi ?? ça sert a rien de mettre 2 fois un point d'exclamation !!")
    }
    else if (message.content == prefix + "vortix"){
        message.channel.send("Lui c'est le créateur")
    }
});
    // Commandes en cours de développement
    client.on("messageCreate", (message) => {
    if (message.content == prefix + "test"){
        let MessageId = message.id;
        message.reply( MessageId )
    }
    if (message.content == prefix + "pp"){
        let msga = message.author;
        message.channel.send("@admin Found one!! " + msga);
    }
});


client.login("TOKEN");